import streamlit as st
import base64 
import os
from dotenv import load_dotenv
from openai import OpenAI
import tempfile

load_dotenv()

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")

client = OpenAI()

sample_prompt = """ You are a medical practictioner and an expert in analyzing medical related data working for a very reputed hospital. You will be provided with the images and need to identify the anomilies, any disease or health issues. You need to generate the results in the detailed manner. write all the findings, next steps, reccommendation,etc. You only need to respond if the image is related to human body and health issues. You must have to answer but also have to write a disclaimer saying that " Consult to a doctor before making any decisions.

if certain aspects are not clear from the image, it's okay to state "Unable to determine based on the provided image.

Now analyze the image and answer the above questions in the same structured manner defined above. """

if 'uploaded_file' not in st.session_state:
    st.session_state.uploaded_state = None

if 'result' not in st.session_state:
    st.session_state.result = None


def encode_image(image_path):
    with open(image_path, 'rb') as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')
    

def call_gpt4_model_for_analysis(filename : str, sample_prompt = sample_prompt):
    base64_image = encode_image(filename)
    

    messages = [
        {
        
        "role" : "user",
        "content": [
            {
                "type" : "text","text": sample_prompt
            },

            {
                "type":"image_url",
                "image_url": {
                    "url" : f"data:image/jpeg;base64,{base64_image}",
                    "details": "high"
                }
            }
        ]
            }


        ]

    

    response = client.chat.completions.create(
        model="gpt-4-vision-preview",
        messages=messages,
        max_tokens=2000
    )

    print(response.choices[0].message.content)
    return response.choices[0].message.content


def chat_eli(query):
    eli5_prompt = "You have to explain the below piece of information to a 5 years old \n" + query
    messages = [
        {
            "role" : "user",
            "content" : eli5_prompt
        }
    ]
    response = client.chat.completions.create(
        model= "gpt-3.5-turbo",
        messages=messages,
        max_tokens=1500
    )

    return  response.choices[0].message.content

st.title("WAHC Medical Image Analyzer Bot")

with st.expander("About the app"):
    st.write("Upload a Medical image to get a detailed analysis from GPT-4V")


uploaded_file = st.file_uploader("Upload your image", type= ["jpg", "png", "jpeg"])

if uploaded_file is not None:
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(uploaded_file.name)[1]) as tmp_file:
        tmp_file.write(uploaded_file.getvalue())
        st.session_state['filename'] = tmp_file.name

    
    st.image(uploaded_file, caption="Uploaded Image")

if st.button("Analyze image"):
    if 'filename' in st.session_state and os.path.exists(st.session_state['filename']):
        st.session_state['result'] = call_gpt4_model_for_analysis(st.session_state['filename'])
        st.markdown(st.session_state['result'], unsafe_allow_html=True)
        os.unlink(st.session_state['filename'])

if 'result' in st.session_state and st.session_state['result']:
    st.info("Below is your result for Simplify It to understand it in simpler words.")

    if st.radio("Simplify It", ('No', 'Yes')) == 'Yes':
        simplified_result = chat_eli(st.session_state['result'])
        st.markdown(simplified_result, unsafe_allow_html=True)

